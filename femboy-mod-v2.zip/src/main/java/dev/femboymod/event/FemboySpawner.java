package dev.femboymod.event;

import dev.femboymod.entity.FemboyEntity;
import dev.femboymod.entity.FurroEntity;
import dev.femboymod.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Cada 2 minutos aparece un Femboy cerca de cada jugador y lo ataca. */
public class FemboySpawner {
    public static final int INTERVAL_TICKS = 20 * 60 * 2;
    private static final int MAX_NEARBY = 3;

    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        int tick = server.getTickCount();
        if (tick == 0 || tick % INTERVAL_TICKS != 0) {
            return;
        }
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.isSpectator() || !(player.level() instanceof ServerLevel level)) {
                continue;
            }
            if (level.getDifficulty() == Difficulty.PEACEFUL) {
                continue;
            }
            spawnNear(level, player);
        }
    }

    /** Entre 1 y 3 furros acompanan al Femboy en cada oleada. */
    private static void spawnFurros(ServerLevel level, ServerPlayer player, FemboyEntity femboy, RandomSource random) {
        int count = 1 + random.nextInt(3);
        FurroEntity.Kind[] kinds = FurroEntity.Kind.values();
        for (int i = 0; i < count; i++) {
            FurroEntity furro = FurroEntity.create(kinds[random.nextInt(kinds.length)], level);
            furro.setPos(femboy.getX() + random.nextInt(5) - 2, femboy.getY(), femboy.getZ() + random.nextInt(5) - 2);
            if (level.noCollision(furro)) {
                furro.setTarget(player);
                level.addFreshEntity(furro);
            }
        }
    }

    private static void spawnNear(ServerLevel level, ServerPlayer player) {
        int nearby = level.getEntitiesOfClass(FemboyEntity.class, player.getBoundingBox().inflate(64.0D)).size();
        if (nearby >= MAX_NEARBY) {
            return;
        }

        RandomSource random = level.getRandom();
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double distance = 10.0D + random.nextInt(8);
            int x = Mth.floor(player.getX() + Math.cos(angle) * distance);
            int z = Mth.floor(player.getZ() + Math.sin(angle) * distance);
            int y = level.dimensionType().hasCeiling()
                    ? player.blockPosition().getY()
                    : level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);

            FemboyEntity femboy = new FemboyEntity(ModEntities.FEMBOY.get(), level);
            femboy.setPos(x + 0.5D, y, z + 0.5D);
            if (level.noCollision(femboy)) {
                femboy.setTarget(player);
                level.addFreshEntity(femboy);
                spawnFurros(level, player, femboy, random);
                player.displayClientMessage(Component.translatable("message.femboy.aparecio"), true);
                return;
            }
        }
    }
}
