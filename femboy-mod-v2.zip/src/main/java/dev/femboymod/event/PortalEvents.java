package dev.femboymod.event;

import dev.femboymod.FemboyMod;
import dev.femboymod.registry.ModBlocks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Teletransporte del portal de Femboy. Usa comandos (/execute in ... run tp) para no depender
 * de la API interna de cambio de dimension. Guarda de donde vienes en una etiqueta del jugador.
 */
public class PortalEvents {
    private static final String BACK_PREFIX = "femboy_back_";
    private static final ResourceKey<Level> REINO = ResourceKey.create(Registries.DIMENSION,
            ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "reino_femboy"));
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        if (player.tickCount % 5 != 0) {
            return;
        }
        BlockPos feet = player.blockPosition();
        BlockPos eyes = BlockPos.containing(player.getEyePosition());
        if (!isPortal(level.getBlockState(feet)) && !isPortal(level.getBlockState(eyes))) {
            return;
        }

        long now = level.getGameTime();
        Long until = COOLDOWN.get(player.getUUID());
        if (until != null && now < until) {
            return;
        }
        COOLDOWN.put(player.getUUID(), now + 200L);

        MinecraftServer server = level.getServer();
        if (level.dimension().equals(REINO)) {
            volverAlMundo(server, player);
        } else {
            irAlReino(server, player);
        }
    }

    private static boolean isPortal(BlockState state) {
        return state.is(ModBlocks.PORTAL_FEMBOY.get());
    }

    private static void irAlReino(MinecraftServer server, ServerPlayer player) {
        for (String tag : new ArrayList<>(player.getTags())) {
            if (tag.startsWith(BACK_PREFIX)) {
                player.removeTag(tag);
            }
        }
        player.addTag(BACK_PREFIX + String.format(Locale.ROOT, "%.2f_%.2f_%.2f",
                player.getX(), player.getY(), player.getZ()));

        runCommand(server, "execute in femboy:reino_femboy run tp " + player.getStringUUID() + " 1.5 0 3.5 180 0");

        ServerLevel reino = server.getLevel(REINO);
        if (reino != null) {
            construirPortalDeRegreso(reino);
        }
    }

    private static void volverAlMundo(MinecraftServer server, ServerPlayer player) {
        String back = null;
        for (String tag : player.getTags()) {
            if (tag.startsWith(BACK_PREFIX)) {
                back = tag.substring(BACK_PREFIX.length());
                break;
            }
        }
        if (back != null) {
            String[] p = back.split("_");
            runCommand(server, "execute in minecraft:overworld run tp " + player.getStringUUID()
                    + " " + p[0] + " " + p[1] + " " + p[2]);
        } else {
            runCommand(server, "execute in minecraft:overworld positioned 0 0 0 positioned over world_surface run tp "
                    + player.getStringUUID() + " ~ ~ ~");
        }
    }

    private static void runCommand(MinecraftServer server, String command) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
    }

    /** Portal de regreso fijo en (0,0,0) de la dimension: marco de 4x5 a lo largo del eje X. */
    private static void construirPortalDeRegreso(ServerLevel reino) {
        for (int x = 0; x <= 3; x++) {
            for (int y = 0; y <= 4; y++) {
                boolean border = x == 0 || x == 3 || y == 0 || y == 4;
                reino.setBlock(new BlockPos(x, y, 0),
                        (border ? ModBlocks.MARCO_PORTAL : ModBlocks.PORTAL_FEMBOY).get().defaultBlockState(), 3);
            }
        }
    }
}
