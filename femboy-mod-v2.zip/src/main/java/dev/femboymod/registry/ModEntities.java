package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import dev.femboymod.entity.FemboyEntity;
import dev.femboymod.entity.FurroEntity;
import dev.femboymod.entity.ReinaFurraEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, FemboyMod.MOD_ID);

    public static final DeferredHolder<EntityType<?>, EntityType<FemboyEntity>> FEMBOY = ENTITIES.register(
            "femboy",
            registryName -> EntityType.Builder.of(FemboyEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, registryName)));

    public static final DeferredHolder<EntityType<?>, EntityType<FurroEntity>> FURRO_GUERRERO = ENTITIES.register(
            "furro_guerrero",
            registryName -> EntityType.Builder.<FurroEntity>of(
                            (type, level) -> new FurroEntity(type, level, FurroEntity.Kind.GUERRERO), MobCategory.MONSTER)
                    .sized(0.6F, 1.9F)
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, registryName)));

    public static final DeferredHolder<EntityType<?>, EntityType<FurroEntity>> FURRO_ARQUERO = ENTITIES.register(
            "furro_arquero",
            registryName -> EntityType.Builder.<FurroEntity>of(
                            (type, level) -> new FurroEntity(type, level, FurroEntity.Kind.ARQUERO), MobCategory.MONSTER)
                    .sized(0.6F, 1.9F)
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, registryName)));

    public static final DeferredHolder<EntityType<?>, EntityType<FurroEntity>> FURRO_TANQUE = ENTITIES.register(
            "furro_tanque",
            registryName -> EntityType.Builder.<FurroEntity>of(
                            (type, level) -> new FurroEntity(type, level, FurroEntity.Kind.TANQUE), MobCategory.MONSTER)
                    .sized(0.7F, 2.0F)
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, registryName)));

    public static final DeferredHolder<EntityType<?>, EntityType<ReinaFurraEntity>> REINA_FURRA = ENTITIES.register(
            "reina_furra",
            registryName -> EntityType.Builder.of(ReinaFurraEntity::new, MobCategory.MONSTER)
                    .sized(0.8F, 2.2F)
                    .clientTrackingRange(16)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, registryName)));
}
