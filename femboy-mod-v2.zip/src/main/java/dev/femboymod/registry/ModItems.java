package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import dev.femboymod.item.BaculoCorazonesItem;
import dev.femboymod.item.BrujulaFemboyItem;
import dev.femboymod.item.CanonBilletesItem;
import dev.femboymod.item.OrbeFemboyItem;
import dev.femboymod.item.VacunaItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.equipment.ArmorType;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(FemboyMod.MOD_ID);

    // --- Fase 1 ---
    public static final DeferredItem<Item> BILLETE = ITEMS.registerSimpleItem("billete", new Item.Properties());

    public static final DeferredItem<Item> BILLETE_FEMBOY = ITEMS.registerSimpleItem(
            "billete_femboy", new Item.Properties().rarity(Rarity.EPIC));

    public static final DeferredItem<BlockItem> FEMBOYFICADORA = ITEMS.registerSimpleBlockItem(ModBlocks.FEMBOYFICADORA);

    // --- Fase 2: armas ---
    public static final DeferredItem<Item> ESPADA_ROSA = ITEMS.registerItem("espada_rosa",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL, 5.0F, -2.4F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> HACHA_FEMBOY = ITEMS.registerItem("hacha_femboy",
            props -> new AxeItem(ModMaterials.FEMBOY_TOOL, 8.0F, -3.0F, props.rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> MARTILLO_FEMBOY = ITEMS.registerItem("martillo_femboy",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL, 7.0F, -3.1F).rarity(Rarity.EPIC)));

    // --- Fase 2: armas OP ---
    public static final DeferredItem<Item> ORBE_FEMBOY = ITEMS.registerItem("orbe_femboy",
            props -> new OrbeFemboyItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> BACULO_CORAZONES = ITEMS.registerItem("baculo_corazones",
            props -> new BaculoCorazonesItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> CANON_BILLETES = ITEMS.registerItem("canon_billetes",
            props -> new CanonBilletesItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    // --- Fase 2: armadura ---
    public static final DeferredItem<Item> FEMBOY_HELMET = ITEMS.registerItem("femboy_helmet",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.HELMET).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FEMBOY_CHESTPLATE = ITEMS.registerItem("femboy_chestplate",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.CHESTPLATE).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FEMBOY_LEGGINGS = ITEMS.registerItem("femboy_leggings",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.LEGGINGS).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FEMBOY_BOOTS = ITEMS.registerItem("femboy_boots",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.BOOTS).rarity(Rarity.EPIC)));

    // --- Fase 3: plaga y laboratorio ---
    public static final DeferredItem<Item> MUESTRA_PLAGA = ITEMS.registerSimpleItem("muestra_plaga", new Item.Properties());

    public static final DeferredItem<Item> VACUNA = ITEMS.registerItem("vacuna",
            props -> new VacunaItem(props.stacksTo(16).rarity(Rarity.RARE)));

    public static final DeferredItem<Item> ESPADA_ANTIPLAGA = ITEMS.registerItem("espada_antiplaga",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL, 4.0F, -2.4F).rarity(Rarity.EPIC)));

    public static final DeferredItem<BlockItem> MESA_INVESTIGACION = ITEMS.registerSimpleBlockItem(ModBlocks.MESA_INVESTIGACION);

    // --- Fase 4: portal, dimension y jefa ---
    public static final DeferredItem<Item> LLAVE_FEMBOY = ITEMS.registerSimpleItem(
            "llave_femboy", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    public static final DeferredItem<Item> CORAZON_REINA = ITEMS.registerSimpleItem(
            "corazon_reina", new Item.Properties().rarity(Rarity.EPIC));

    public static final DeferredItem<Item> TROFEO_REINA = ITEMS.registerSimpleItem(
            "trofeo_reina", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    public static final DeferredItem<BlockItem> MARCO_PORTAL = ITEMS.registerSimpleBlockItem(ModBlocks.MARCO_PORTAL);

    // --- Brujula y misiones ---
    public static final DeferredItem<Item> BRUJULA = ITEMS.registerItem("brujula_femboy",
            props -> new BrujulaFemboyItem(props.stacksTo(1).rarity(Rarity.RARE)));
}
