package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import dev.femboymod.effect.PlagaRosaEffect;
import dev.femboymod.effect.SimpleEffect;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(Registries.MOB_EFFECT, FemboyMod.MOD_ID);

    public static final DeferredHolder<MobEffect, PlagaRosaEffect> PLAGA_ROSA =
            EFFECTS.register("plaga_rosa", PlagaRosaEffect::new);

    public static final DeferredHolder<MobEffect, SimpleEffect> VACUNA =
            EFFECTS.register("vacuna", () -> new SimpleEffect(MobEffectCategory.BENEFICIAL, 0x66FFAA));
}
