package dev.femboymod.network;

import dev.femboymod.FemboyMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Servidor -> cliente: mision actual y, si la hay, el objetivo al que apunta la brujula. */
public record QuestPayload(int stage, boolean hasTarget, int x, int z, boolean reino) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<QuestPayload> TYPE = new CustomPacketPayload.Type<>(
            ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "quest"));

    public static final StreamCodec<RegistryFriendlyByteBuf, QuestPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, QuestPayload::stage,
            ByteBufCodecs.BOOL, QuestPayload::hasTarget,
            ByteBufCodecs.INT, QuestPayload::x,
            ByteBufCodecs.INT, QuestPayload::z,
            ByteBufCodecs.BOOL, QuestPayload::reino,
            QuestPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
