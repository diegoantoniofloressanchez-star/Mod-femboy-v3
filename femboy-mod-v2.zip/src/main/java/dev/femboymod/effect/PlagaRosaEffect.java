package dev.femboymod.effect;

import dev.femboymod.FemboyMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** Plaga Rosa: te hace mas lento y debil hasta que te vacunas. */
public class PlagaRosaEffect extends MobEffect {
    public PlagaRosaEffect() {
        super(MobEffectCategory.HARMFUL, 0xFF69B4);
        this.addAttributeModifier(Attributes.MOVEMENT_SPEED,
                ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "plaga_rosa_speed"),
                -0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        this.addAttributeModifier(Attributes.ATTACK_DAMAGE,
                ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "plaga_rosa_attack"),
                -0.25D, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
    }
}
