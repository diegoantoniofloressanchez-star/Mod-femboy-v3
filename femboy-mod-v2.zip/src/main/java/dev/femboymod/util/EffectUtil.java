package dev.femboymod.util;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

/** Busca efectos por su id ("speed", "regeneration"...) para no depender de los nombres de MobEffects. */
public final class EffectUtil {
    private EffectUtil() {}

    public static Holder<MobEffect> get(String id) {
        return BuiltInRegistries.MOB_EFFECT
                .getOrThrow(ResourceKey.create(Registries.MOB_EFFECT, ResourceLocation.withDefaultNamespace(id)));
    }

    public static MobEffectInstance of(String id, int duration, int amplifier) {
        return new MobEffectInstance(get(id), duration, amplifier);
    }

    /** Efecto discreto (sin particulas) para el bonus de armadura. */
    public static MobEffectInstance quiet(String id, int duration, int amplifier) {
        return new MobEffectInstance(get(id), duration, amplifier, true, false, true);
    }
}
