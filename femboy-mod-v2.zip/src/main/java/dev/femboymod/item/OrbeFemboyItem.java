package dev.femboymod.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/** Orbe del Femboy: onda de energia rosa que daña y empuja a los enemigos cercanos. */
public class OrbeFemboyItem extends Item {
    public OrbeFemboyItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            AABB area = player.getBoundingBox().inflate(7.0D);
            for (LivingEntity target : server.getEntitiesOfClass(LivingEntity.class, area,
                    e -> e instanceof Enemy && e.isAlive())) {
                target.hurtServer(server, server.damageSources().playerAttack(player), 14.0F);
                target.knockback(1.6D, player.getX() - target.getX(), player.getZ() - target.getZ());
            }
            server.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.0D, player.getZ(),
                    60, 3.0D, 0.6D, 3.0D, 0.05D);
            server.sendParticles(ParticleTypes.EXPLOSION, player.getX(), player.getY() + 1.0D, player.getZ(),
                    6, 2.5D, 0.4D, 2.5D, 0.0D);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE,
                    SoundSource.PLAYERS, 1.5F, 0.7F);
        }
        player.getCooldowns().addCooldown(stack, 100);
        return InteractionResult.SUCCESS;
    }
}
