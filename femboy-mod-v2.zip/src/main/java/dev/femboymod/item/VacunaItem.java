package dev.femboymod.item;

import dev.femboymod.registry.ModEffects;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Vacuna: cura la Plaga Rosa y da inmunidad durante 30 minutos. */
public class VacunaItem extends Item {
    public static final int INMUNIDAD_TICKS = 20 * 60 * 30;

    public VacunaItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            player.removeEffect(ModEffects.PLAGA_ROSA);
            player.addEffect(new MobEffectInstance(ModEffects.VACUNA, INMUNIDAD_TICKS, 0, false, true, true));
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            server.sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0D, player.getZ(),
                    15, 0.4D, 0.6D, 0.4D, 0.0D);
            level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 1.4F);
        }
        return InteractionResult.SUCCESS;
    }
}
