package dev.femboymod.item;

import dev.femboymod.util.EffectUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Baculo de Corazones: cura y da buffs a ti y a los jugadores cercanos. */
public class BaculoCorazonesItem extends Item {
    public BaculoCorazonesItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            for (Player ally : server.getEntitiesOfClass(Player.class, player.getBoundingBox().inflate(10.0D))) {
                ally.heal(8.0F);
                ally.addEffect(EffectUtil.of("regeneration", 200, 2));
                ally.addEffect(EffectUtil.of("absorption", 600, 2));
                ally.addEffect(EffectUtil.of("strength", 400, 1));
                server.sendParticles(ParticleTypes.HEART, ally.getX(), ally.getY() + 1.0D, ally.getZ(),
                        12, 0.4D, 0.5D, 0.4D, 0.0D);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE,
                    SoundSource.PLAYERS, 1.2F, 1.3F);
        }
        player.getCooldowns().addCooldown(stack, 600);
        return InteractionResult.SUCCESS;
    }
}
