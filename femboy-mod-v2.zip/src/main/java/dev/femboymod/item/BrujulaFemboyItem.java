package dev.femboymod.item;

import dev.femboymod.quest.QuestManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Brujula del Femboy: clic derecho para marcar el objetivo de la mision actual (flecha en el HUD al sostenerla). */
public class BrujulaFemboyItem extends Item {
    public BrujulaFemboyItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer serverPlayer) {
            QuestManager.calibrate(serverPlayer);
        }
        player.getCooldowns().addCooldown(player.getItemInHand(hand), 40);
        return InteractionResult.SUCCESS;
    }
}
