package dev.femboymod.item;

import dev.femboymod.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Canon de Billetes: gasta 1 billete normal y provoca una explosion donde apuntas (no rompe bloques). */
public class CanonBilletesItem extends Item {
    public CanonBilletesItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        Inventory inv = player.getInventory();
        boolean creative = player.getAbilities().instabuild;

        int slot = -1;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.BILLETE.get())) {
                slot = i;
                break;
            }
        }
        if (slot < 0 && !creative) {
            if (!level.isClientSide()) {
                player.displayClientMessage(Component.translatable("message.femboy.sin_billetes"), true);
            }
            return InteractionResult.FAIL;
        }

        if (level instanceof ServerLevel server) {
            if (!creative) {
                inv.getItem(slot).shrink(1);
            }
            Vec3 eye = player.getEyePosition();
            HitResult hit = player.pick(40.0D, 0.0F, false);
            Vec3 end = hit.getLocation();
            Vec3 dir = end.subtract(eye);
            int steps = Math.max(2, (int) (dir.length() * 2.0D));
            for (int i = 2; i < steps; i++) {
                Vec3 p = eye.add(dir.scale(i / (double) steps));
                server.sendParticles(ParticleTypes.HEART, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
            level.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH,
                    SoundSource.PLAYERS, 1.0F, 0.8F);
            server.explode(player, end.x, end.y, end.z, 2.5F, Level.ExplosionInteraction.NONE);
        }
        player.getCooldowns().addCooldown(stack, 20);
        return InteractionResult.SUCCESS;
    }
}
