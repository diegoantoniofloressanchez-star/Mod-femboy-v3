package dev.femboymod.block;

import net.minecraft.world.level.block.Block;

/** Interior del portal activado. No tiene colision: el teletransporte lo hace PortalEvents. */
public class PortalFemboyBlock extends Block {
    public PortalFemboyBlock(Properties properties) {
        super(properties);
    }
}
