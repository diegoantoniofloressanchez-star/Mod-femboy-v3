package dev.femboymod.block;

import dev.femboymod.quest.QuestManager;
import dev.femboymod.registry.ModBlocks;
import dev.femboymod.registry.ModItems;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Marco del portal a la Dimension Femboy. Clic derecho con la Llave de Femboy:
 * busca el hueco vacio del marco (en cualquier orientacion) y lo llena con el portal.
 */
public class MarcoPortalBlock extends Block {
    private static final int MAX_CELLS = 16;

    public MarcoPortalBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                          Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(ModItems.LLAVE_FEMBOY.get())) {
            return InteractionResult.TRY_WITH_EMPTY_HAND;
        }
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        List<BlockPos> cells = findInterior(level, pos);
        if (cells == null) {
            player.displayClientMessage(Component.translatable("message.femboy.portal_invalido"), true);
            return InteractionResult.CONSUME;
        }

        for (BlockPos cell : cells) {
            level.setBlock(cell, ModBlocks.PORTAL_FEMBOY.get().defaultBlockState(), 3);
        }
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        level.playSound(null, pos, SoundEvents.END_PORTAL_SPAWN, SoundSource.BLOCKS, 0.8F, 1.4F);
        if (level instanceof ServerLevel server) {
            for (BlockPos cell : cells) {
                server.sendParticles(ParticleTypes.HEART, cell.getX() + 0.5, cell.getY() + 0.5, cell.getZ() + 0.5,
                        4, 0.3, 0.3, 0.3, 0.0);
            }
        }
        player.displayClientMessage(Component.translatable("message.femboy.portal_activado"), true);
        if (player instanceof ServerPlayer serverPlayer) {
            QuestManager.complete(serverPlayer, 8);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (!level.isClientSide()) {
            player.displayClientMessage(Component.translatable("message.femboy.necesita_llave"), true);
        }
        return InteractionResult.SUCCESS;
    }

    private static List<BlockPos> findInterior(Level level, BlockPos origin) {
        for (Direction.Axis axis : new Direction.Axis[] {Direction.Axis.X, Direction.Axis.Z}) {
            Direction[] dirs = planeDirections(axis);
            for (Direction d : dirs) {
                BlockPos start = origin.relative(d);
                if (!level.getBlockState(start).isAir()) {
                    continue;
                }
                List<BlockPos> result = flood(level, start, dirs);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }

    private static Direction[] planeDirections(Direction.Axis horizontal) {
        return new Direction[] {
                Direction.fromAxisAndDirection(horizontal, Direction.AxisDirection.POSITIVE),
                Direction.fromAxisAndDirection(horizontal, Direction.AxisDirection.NEGATIVE),
                Direction.UP,
                Direction.DOWN};
    }

    private static List<BlockPos> flood(Level level, BlockPos start, Direction[] dirs) {
        Set<BlockPos> seen = new LinkedHashSet<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        seen.add(start);
        queue.add(start);
        while (!queue.isEmpty()) {
            BlockPos p = queue.poll();
            for (Direction d : dirs) {
                BlockPos n = p.relative(d);
                if (seen.contains(n) || !level.getBlockState(n).isAir()) {
                    continue;
                }
                seen.add(n);
                if (seen.size() > MAX_CELLS) {
                    return null;
                }
                queue.add(n);
            }
        }
        return seen.size() >= 4 ? new ArrayList<>(seen) : null;
    }
}
