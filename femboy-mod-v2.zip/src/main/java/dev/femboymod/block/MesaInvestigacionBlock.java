package dev.femboymod.block;

import dev.femboymod.registry.ModItems;
import dev.femboymod.util.InvUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Mesa de Investigacion del Laboratorio Anti-Plaga.
 * - Muestra de plaga en la mano (5 en el inventario) = Vacuna.
 * - Billete de femboy en la mano + 10 muestras en el inventario = Espada Anti-Plaga.
 */
public class MesaInvestigacionBlock extends Block {
    public static final int MUESTRAS_VACUNA = 5;
    public static final int MUESTRAS_ESPADA = 10;

    public MesaInvestigacionBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                          Player player, InteractionHand hand, BlockHitResult hit) {
        boolean muestra = stack.is(ModItems.MUESTRA_PLAGA.get());
        boolean billete = stack.is(ModItems.BILLETE_FEMBOY.get());
        if (!muestra && !billete) {
            return InteractionResult.TRY_WITH_EMPTY_HAND;
        }
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }

        int muestras = InvUtil.count(player, ModItems.MUESTRA_PLAGA.get());
        boolean creative = player.getAbilities().instabuild;

        if (muestra) {
            if (muestras < MUESTRAS_VACUNA && !creative) {
                player.displayClientMessage(Component.translatable("message.femboy.necesita_muestras"), true);
                return InteractionResult.CONSUME;
            }
            if (!creative) {
                InvUtil.remove(player, ModItems.MUESTRA_PLAGA.get(), MUESTRAS_VACUNA);
            }
            InvUtil.give(player, new ItemStack(ModItems.VACUNA.get()));
        } else {
            if (muestras < MUESTRAS_ESPADA && !creative) {
                player.displayClientMessage(Component.translatable("message.femboy.necesita_muestras_espada"), true);
                return InteractionResult.CONSUME;
            }
            if (!creative) {
                stack.shrink(1);
                InvUtil.remove(player, ModItems.MUESTRA_PLAGA.get(), MUESTRAS_ESPADA);
            }
            InvUtil.give(player, new ItemStack(ModItems.ESPADA_ANTIPLAGA.get()));
        }

        level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0F, 1.0F);
        if (level instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                    pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 10, 0.3, 0.2, 0.3, 0.0);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (!level.isClientSide()) {
            player.displayClientMessage(Component.translatable("message.femboy.como_usar_mesa"), true);
        }
        return InteractionResult.SUCCESS;
    }
}
