package dev.femboymod.quest;

import dev.femboymod.network.QuestPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Ultimo estado de misiones recibido del servidor (lo lee el HUD). */
public final class ClientQuestState {
    public static volatile int stage = -1;
    public static volatile boolean hasTarget = false;
    public static volatile int targetX = 0;
    public static volatile int targetZ = 0;
    public static volatile boolean targetReino = false;

    private ClientQuestState() {}

    public static void handle(QuestPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            stage = payload.stage();
            hasTarget = payload.hasTarget();
            targetX = payload.x();
            targetZ = payload.z();
            targetReino = payload.reino();
        });
    }
}
