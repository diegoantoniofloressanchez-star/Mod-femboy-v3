package dev.femboymod.quest;

import dev.femboymod.FemboyMod;
import dev.femboymod.entity.ReinaFurraEntity;
import dev.femboymod.network.QuestPayload;
import dev.femboymod.registry.ModBlocks;
import dev.femboymod.registry.ModEffects;
import dev.femboymod.registry.ModItems;
import dev.femboymod.util.InvUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.ReadOnlyScoreInfo;
import net.minecraft.world.scores.Scoreboard;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Misiones una por una. La etapa actual se guarda en un marcador (scoreboard) "femboy_mision",
 * que se conserva al morir y al reiniciar. El HUD y la brujula reciben la etapa por red.
 *
 * Etapas: 0 Femboyficadora, 1 Billete de Femboy, 2 Calmar Femboy, 3 Muestras, 4 Encontrar laboratorio,
 * 5 Vacuna, 6 Llave, 7 Encontrar portal, 8 Activar portal, 9 Entrar a la dimension,
 * 10 Encontrar castillo, 11 Derrotar a la Reina, 12 = todo completado.
 */
public class QuestManager {
    public static final String OBJECTIVE = "femboy_mision";
    public static final int LAST = 12;

    private static final ResourceKey<Level> REINO = ResourceKey.create(Registries.DIMENSION,
            ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "reino_femboy"));
    private static final TagKey<Structure> LAB = structureTag("laboratorio");
    private static final TagKey<Structure> PORTAL = structureTag("portal_ruinas");
    private static final TagKey<Structure> CASTILLO = structureTag("castillo_reina");

    private record Target(int x, int z, boolean reino) {}
    private static final Map<UUID, Target> TARGETS = new HashMap<>();
    private static final Map<UUID, Integer> FALLBACK = new HashMap<>();

    private static TagKey<Structure> structureTag(String name) {
        return TagKey.create(Registries.STRUCTURE, ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, name));
    }

    public static void register() {
        NeoForge.EVENT_BUS.addListener(QuestManager::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(QuestManager::onLogin);
        NeoForge.EVENT_BUS.addListener(QuestManager::onDeath);
    }

    // ---------- almacenamiento de la etapa ----------
    private static Objective objective(MinecraftServer server) {
        Scoreboard sb = server.getScoreboard();
        Objective o = sb.getObjective(OBJECTIVE);
        if (o == null) {
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),
                    "scoreboard objectives add " + OBJECTIVE + " dummy");
            o = sb.getObjective(OBJECTIVE);
        }
        return o;
    }

    /** -1 si el jugador aun no tiene etapa guardada. */
    public static int getStage(ServerPlayer player) {
        Objective o = objective(player.getServer());
        if (o == null) {
            return FALLBACK.getOrDefault(player.getUUID(), -1);
        }
        ReadOnlyScoreInfo info = player.getServer().getScoreboard().getPlayerScoreInfo(player, o);
        return info == null ? -1 : info.value();
    }

    private static void setStage(ServerPlayer player, int stage) {
        Objective o = objective(player.getServer());
        if (o == null) {
            FALLBACK.put(player.getUUID(), stage);
        } else {
            player.getServer().getScoreboard().getOrCreatePlayerScore(player, o).set(stage);
        }
    }

    // ---------- eventos ----------
    private static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (getStage(player) < 0) {
            setStage(player, 0);
            InvUtil.give(player, new ItemStack(ModItems.BRUJULA.get()));
            player.displayClientMessage(Component.translatable("message.femboy.bienvenida"), false);
        }
        sync(player);
    }

    private static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.tickCount % 20 != 0) {
            return;
        }
        int stage = getStage(player);
        if (stage < 0) {
            stage = 0;
            setStage(player, 0);
        }
        advance(player, stage);
    }

    private static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ReinaFurraEntity boss && boss.level() instanceof ServerLevel server) {
            for (ServerPlayer p : server.players()) {
                if (p.distanceToSqr(boss) < 64.0D * 64.0D) {
                    complete(p, 11);
                }
            }
        }
    }

    /** Marca como cumplida una etapa guiada por eventos (solo si es la etapa actual). */
    public static void complete(ServerPlayer player, int stage) {
        if (getStage(player) == stage) {
            advance(player, stage, true);
        }
    }

    private static void advance(ServerPlayer player, int stage) {
        advance(player, stage, false);
    }

    private static void advance(ServerPlayer player, int stage, boolean force) {
        int start = stage;
        if (force) {
            stage++;
        }
        while (stage < LAST && isDone(player, stage)) {
            stage++;
        }
        if (stage != start) {
            setStage(player, stage);
            TARGETS.remove(player.getUUID());
            player.displayClientMessage(Component.translatable(stage >= LAST
                    ? "message.femboy.misiones_completas" : "message.femboy.mision_completada"), false);
            player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                    SoundSource.PLAYERS, 0.7F, 1.3F);
            sync(player);
        }
    }

    // ---------- condiciones de cada etapa ----------
    private static boolean has(Player p, Item item) {
        return InvUtil.count(p, item) > 0;
    }

    private static boolean inStructure(ServerPlayer p, TagKey<Structure> tag) {
        return p.level() instanceof ServerLevel level
                && level.structureManager().getStructureWithPieceAt(p.blockPosition(), tag).isValid();
    }

    private static boolean portalNearby(ServerPlayer p) {
        BlockPos c = p.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-6, -3, -6), c.offset(6, 4, 6))) {
            if (p.level().getBlockState(pos).is(ModBlocks.PORTAL_FEMBOY.get())) {
                return true;
            }
        }
        return false;
    }

    private static boolean vacunado(ServerPlayer p) {
        return has(p, ModItems.VACUNA.get()) || p.hasEffect(ModEffects.VACUNA);
    }

    private static boolean enReino(ServerPlayer p) {
        return p.level().dimension().equals(REINO);
    }

    private static boolean isDone(ServerPlayer p, int stage) {
        return switch (stage) {
            case 0 -> has(p, ModItems.FEMBOYFICADORA.get()) || has(p, ModItems.BILLETE_FEMBOY.get());
            case 1 -> has(p, ModItems.BILLETE_FEMBOY.get());
            case 2 -> false; // se completa al calmar un Femboy (evento)
            case 3 -> InvUtil.count(p, ModItems.MUESTRA_PLAGA.get()) >= 5 || vacunado(p) || has(p, ModItems.LLAVE_FEMBOY.get());
            case 4 -> inStructure(p, LAB) || vacunado(p) || has(p, ModItems.LLAVE_FEMBOY.get());
            case 5 -> vacunado(p) || has(p, ModItems.LLAVE_FEMBOY.get());
            case 6 -> has(p, ModItems.LLAVE_FEMBOY.get()) || portalNearby(p) || enReino(p);
            case 7 -> inStructure(p, PORTAL) || portalNearby(p) || enReino(p);
            case 8 -> portalNearby(p) || enReino(p);
            case 9 -> enReino(p);
            case 10 -> inStructure(p, CASTILLO);
            case 11 -> has(p, ModItems.TROFEO_REINA.get());
            default -> false;
        };
    }

    // ---------- brujula ----------
    private static TagKey<Structure> targetStructure(int stage) {
        return switch (stage) {
            case 4, 5 -> LAB;
            case 7, 8, 9 -> PORTAL;
            case 10, 11 -> CASTILLO;
            default -> null;
        };
    }

    /** Clic derecho con la brujula: busca la estructura de la mision actual y manda la direccion al HUD. */
    public static void calibrate(ServerPlayer player) {
        int stage = getStage(player);
        TagKey<Structure> tag = targetStructure(stage);
        if (tag == null) {
            player.displayClientMessage(Component.translatable("message.femboy.brujula_sin_objetivo"), true);
            return;
        }
        boolean needReino = tag == CASTILLO;
        if (needReino != enReino(player)) {
            player.displayClientMessage(Component.translatable(needReino
                    ? "message.femboy.brujula_ve_al_reino" : "message.femboy.brujula_vuelve_al_mundo"), true);
            return;
        }
        player.displayClientMessage(Component.translatable("message.femboy.brujula_buscando"), true);
        ServerLevel level = (ServerLevel) player.level();
        BlockPos found = level.findNearestMapStructure(tag, player.blockPosition(), 100, false);
        if (found == null) {
            player.displayClientMessage(Component.translatable("message.femboy.brujula_no_encontrado"), true);
            return;
        }
        TARGETS.put(player.getUUID(), new Target(found.getX(), found.getZ(), needReino));
        sync(player);
        player.displayClientMessage(Component.translatable("message.femboy.brujula_listo"), true);
    }

    public static void sync(ServerPlayer player) {
        int stage = Math.max(0, getStage(player));
        Target t = TARGETS.get(player.getUUID());
        PacketDistributor.sendToPlayer(player, t == null
                ? new QuestPayload(stage, false, 0, 0, false)
                : new QuestPayload(stage, true, t.x(), t.z(), t.reino()));
    }
}
