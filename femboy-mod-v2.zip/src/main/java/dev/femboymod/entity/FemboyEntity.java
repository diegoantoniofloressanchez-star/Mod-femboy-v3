package dev.femboymod.entity;

import dev.femboymod.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import dev.femboymod.quest.QuestManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class FemboyEntity extends Monster {
    /** Cuanto dura calmado antes de irse (5 minutos). */
    private static final int CALM_DURATION_TICKS = 20 * 60 * 5;

    private boolean calm = false;
    private int calmTicks = 0;

    public FemboyEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ARMOR, 4.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true) {
            @Override
            public boolean canUse() {
                return !FemboyEntity.this.calm && super.canUse();
            }
        });
    }

    public boolean isCalm() {
        return this.calm;
    }

    /** Lo calma: deja de atacar, suelta corazones y se va despues de un rato. */
    public void calm() {
        this.calm = true;
        this.calmTicks = CALM_DURATION_TICKS;
        super.setTarget(null);
        this.getNavigation().stop();
        this.setAggressive(false);
        this.playSound(SoundEvents.VILLAGER_YES, 1.0F, 1.3F);
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (this.calm) {
            return;
        }
        super.setTarget(target);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.is(ModItems.BILLETE_FEMBOY.get())) {
            if (!this.level().isClientSide() && !this.calm) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.calm();
                if (player instanceof ServerPlayer serverPlayer) {
                    QuestManager.complete(serverPlayer, 2);
                }
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide() && this.calm) {
            this.calmTicks--;
            if (this.calmTicks % 20 == 0 && this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.HEART,
                        this.getX(), this.getY() + 2.0D, this.getZ(), 2, 0.3D, 0.3D, 0.3D, 0.0D);
            }
            if (this.calmTicks <= 0) {
                this.discard();
            }
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }
}
