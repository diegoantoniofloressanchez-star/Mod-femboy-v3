package dev.femboymod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Reina Furra: jefa final de la Dimension Femboy. 3 fases y barra de vida.
 * Fase 1: zarpazos y saltos. Fase 2: invoca furros. Fase 3: mas rapida y lanza ondas de energia rosa.
 */
public class ReinaFurraEntity extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.femboy.reina_furra"),
            BossEvent.BossBarColor.PINK, BossEvent.BossBarOverlay.PROGRESS);

    private int phase = 1;
    private int timer = 0;

    public ReinaFurraEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void tick() {
        super.tick();
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        if (this.isDeadOrDying()) {
            this.bossEvent.removeAllPlayers();
            return;
        }

        float ratio = this.getHealth() / this.getMaxHealth();
        this.bossEvent.setProgress(ratio);
        int newPhase = ratio > 0.66F ? 1 : (ratio > 0.33F ? 2 : 3);
        if (newPhase != this.phase) {
            this.phase = newPhase;
            this.onPhaseChange(server);
        }

        this.timer++;
        LivingEntity target = this.getTarget();
        if (target == null) {
            return;
        }

        // Salto hacia el objetivo (fases 1 y 3)
        int leapEvery = this.phase == 3 ? 100 : 120;
        if (this.phase != 2 && this.timer % leapEvery == 0 && this.distanceTo(target) < 12.0F && this.onGround()) {
            Vec3 d = target.position().subtract(this.position()).normalize().scale(0.9D);
            this.setDeltaMovement(d.x, 0.6D, d.z);
            this.hasImpulse = true;
        }

        // Fase 2: invoca furros
        if (this.phase == 2 && this.timer % 300 == 0) {
            int nearby = server.getEntitiesOfClass(FurroEntity.class, this.getBoundingBox().inflate(24.0D)).size();
            if (nearby < 6) {
                FurroEntity.Kind[] kinds = {FurroEntity.Kind.GUERRERO, FurroEntity.Kind.GUERRERO, FurroEntity.Kind.ARQUERO};
                for (int i = 0; i < kinds.length; i++) {
                    FurroEntity furro = FurroEntity.create(kinds[i], server);
                    furro.setPos(this.getX() + this.random.nextInt(7) - 3, this.getY(), this.getZ() + this.random.nextInt(7) - 3);
                    furro.setTarget(target);
                    server.addFreshEntity(furro);
                }
                server.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 2.0D, this.getZ(),
                        30, 2.0D, 1.0D, 2.0D, 0.0D);
            }
        }

        // Fase 3: onda de energia rosa
        if (this.phase == 3 && this.timer % 80 == 0) {
            for (Player p : server.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(9.0D))) {
                p.hurtServer(server, server.damageSources().mobAttack(this), 10.0F);
                p.knockback(1.2D, this.getX() - p.getX(), this.getZ() - p.getZ());
            }
            server.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 1.0D, this.getZ(),
                    80, 4.0D, 0.6D, 4.0D, 0.05D);
            server.sendParticles(ParticleTypes.EXPLOSION, this.getX(), this.getY() + 1.0D, this.getZ(),
                    8, 3.5D, 0.4D, 3.5D, 0.0D);
            server.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE,
                    SoundSource.HOSTILE, 2.0F, 0.6F);
        }
    }

    private void onPhaseChange(ServerLevel server) {
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (this.phase == 2) {
            this.bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
            if (speed != null) {
                speed.setBaseValue(0.32D);
            }
        } else if (this.phase == 3) {
            this.bossEvent.setColor(BossEvent.BossBarColor.RED);
            if (speed != null) {
                speed.setBaseValue(0.40D);
            }
        }
        server.playSound(null, this.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 2.0F, 0.8F);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.FOX_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.FOX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.FOX_DEATH;
    }
}
