package dev.femboymod.entity;

import dev.femboymod.registry.ModEntities;
import java.util.EnumSet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Furro: secuaz del Femboy. Sus golpes contagian la Plaga Rosa (ver CombatEvents). */
public class FurroEntity extends Monster {
    public enum Kind { GUERRERO, ARQUERO, TANQUE }

    private final Kind kind;

    public FurroEntity(EntityType<? extends Monster> type, Level level, Kind kind) {
        super(type, level);
        this.kind = kind;
    }

    public Kind getKind() {
        return kind;
    }

    public static FurroEntity create(Kind kind, Level level) {
        EntityType<FurroEntity> type = switch (kind) {
            case GUERRERO -> ModEntities.FURRO_GUERRERO.get();
            case ARQUERO -> ModEntities.FURRO_ARQUERO.get();
            case TANQUE -> ModEntities.FURRO_TANQUE.get();
        };
        return new FurroEntity(type, level, kind);
    }

    public static AttributeSupplier.Builder attributes(Kind kind) {
        AttributeSupplier.Builder b = Monster.createMonsterAttributes()
                .add(Attributes.FOLLOW_RANGE, 40.0D);
        return switch (kind) {
            case GUERRERO -> b.add(Attributes.MAX_HEALTH, 30.0D)
                    .add(Attributes.MOVEMENT_SPEED, 0.30D)
                    .add(Attributes.ATTACK_DAMAGE, 5.0D);
            case ARQUERO -> b.add(Attributes.MAX_HEALTH, 20.0D)
                    .add(Attributes.MOVEMENT_SPEED, 0.28D)
                    .add(Attributes.ATTACK_DAMAGE, 3.0D);
            case TANQUE -> b.add(Attributes.MAX_HEALTH, 70.0D)
                    .add(Attributes.MOVEMENT_SPEED, 0.21D)
                    .add(Attributes.ATTACK_DAMAGE, 9.0D)
                    .add(Attributes.ARMOR, 8.0D)
                    .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
        };
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (this.kind == Kind.ARQUERO) {
            this.goalSelector.addGoal(2, new BoltGoal(this));
        } else {
            this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1D, false));
        }
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.FOX_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.FOX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.FOX_DEATH;
    }

    /** El arquero dispara un rayo rosa a distancia. */
    private static class BoltGoal extends Goal {
        private final FurroEntity mob;
        private int cooldown;

        BoltGoal(FurroEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = mob.getTarget();
            return target != null && target.isAlive();
        }

        @Override
        public void start() {
            cooldown = 20;
        }

        @Override
        public void tick() {
            LivingEntity target = mob.getTarget();
            if (target == null) {
                return;
            }
            mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
            double dist = mob.distanceTo(target);
            boolean sight = mob.getSensing().hasLineOfSight(target);

            if (dist > 14.0D || !sight) {
                mob.getNavigation().moveTo(target, 1.0D);
            } else {
                mob.getNavigation().stop();
            }

            cooldown--;
            if (cooldown <= 0 && sight && dist <= 16.0D && mob.level() instanceof ServerLevel server) {
                Vec3 from = mob.getEyePosition();
                Vec3 to = target.getEyePosition();
                Vec3 dir = to.subtract(from);
                int steps = Math.max(2, (int) (dir.length() * 2.0D));
                for (int i = 1; i < steps; i++) {
                    Vec3 p = from.add(dir.scale(i / (double) steps));
                    server.sendParticles(ParticleTypes.HEART, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                }
                target.hurtServer(server, server.damageSources().mobAttack(mob), 4.0F);
                cooldown = 40;
            }
        }
    }
}
