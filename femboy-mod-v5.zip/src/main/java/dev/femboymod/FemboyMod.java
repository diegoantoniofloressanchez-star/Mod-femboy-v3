package dev.femboymod;

import dev.femboymod.entity.FemboyEntity;
import dev.femboymod.entity.FurroEntity;
import dev.femboymod.entity.ReinaFurraEntity;
import dev.femboymod.event.CombatEvents;
import dev.femboymod.event.FemboySpawner;
import dev.femboymod.event.ItemEvents;
import dev.femboymod.event.PortalEvents;
import dev.femboymod.network.QuestPayload;
import dev.femboymod.quest.ClientQuestState;
import dev.femboymod.quest.QuestManager;
import dev.femboymod.registry.ModBlocks;
import dev.femboymod.registry.ModCreativeTabs;
import dev.femboymod.registry.ModEffects;
import dev.femboymod.registry.ModEntities;
import dev.femboymod.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@Mod(FemboyMod.MOD_ID)
public class FemboyMod {
    public static final String MOD_ID = "femboy";

    public FemboyMod(IEventBus modBus, ModContainer container) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModEffects.EFFECTS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        modBus.addListener(FemboyMod::registerAttributes);
        modBus.addListener(FemboyMod::registerPayloads);
        QuestManager.register();
        NeoForge.EVENT_BUS.addListener(FemboySpawner::onServerTick);
        NeoForge.EVENT_BUS.addListener(CombatEvents::onDamage);
        NeoForge.EVENT_BUS.addListener(CombatEvents::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(PortalEvents::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(ItemEvents::onFinish);
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(QuestPayload.TYPE, QuestPayload.CODEC, ClientQuestState::handle);
    }

    private static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.FEMBOY.get(), FemboyEntity.createAttributes().build());
        event.put(ModEntities.FURRO_GUERRERO.get(), FurroEntity.attributes(FurroEntity.Kind.GUERRERO).build());
        event.put(ModEntities.FURRO_ARQUERO.get(), FurroEntity.attributes(FurroEntity.Kind.ARQUERO).build());
        event.put(ModEntities.FURRO_TANQUE.get(), FurroEntity.attributes(FurroEntity.Kind.TANQUE).build());
        event.put(ModEntities.REINA_FURRA.get(), ReinaFurraEntity.createAttributes().build());
    }
}
