package dev.femboymod.event;

import dev.femboymod.entity.FurroEntity;
import dev.femboymod.entity.ReinaFurraEntity;
import dev.femboymod.registry.ModEffects;
import dev.femboymod.registry.ModItems;
import dev.femboymod.util.EffectUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Efectos de las armas al golpear y bonus del set completo de armadura. */
public class CombatEvents {
    private static boolean sweeping = false;

    public static void onDamage(LivingDamageEvent.Post event) {
        LivingEntity victim = event.getEntity();
        if (!(victim.level() instanceof ServerLevel server)) {
            return;
        }
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker)
                || event.getSource().getDirectEntity() != attacker) {
            return;
        }
        ItemStack weapon = attacker.getMainHandItem();

        // Los furros contagian la Plaga Rosa (la vacuna da inmunidad)
        if ((attacker instanceof FurroEntity || attacker instanceof ReinaFurraEntity) && victim instanceof Player player) {
            if (!player.hasEffect(ModEffects.VACUNA)) {
                player.addEffect(new MobEffectInstance(ModEffects.PLAGA_ROSA, 20 * 60 * 3, 0));
                player.addEffect(EffectUtil.of("nausea", 100, 0));
            }
            return;
        }

        if (weapon.is(ModItems.ESPADA_ANTIPLAGA.get()) && victim instanceof FurroEntity && !sweeping) {
            sweeping = true;
            try {
                victim.hurtServer(server, event.getSource(), event.getNewDamage() * 0.75F);
                server.sendParticles(ParticleTypes.HAPPY_VILLAGER, victim.getX(), victim.getY() + 1.0D,
                        victim.getZ(), 8, 0.3D, 0.5D, 0.3D, 0.0D);
            } finally {
                sweeping = false;
            }
        } else if (weapon.is(ModItems.GUADANA_REINA.get())) {
            attacker.heal(event.getNewDamage() * 0.3F);
            server.sendParticles(ParticleTypes.HEART, attacker.getX(), attacker.getY() + 1.5D, attacker.getZ(),
                    4, 0.3D, 0.3D, 0.3D, 0.0D);
        } else if (weapon.is(ModItems.LANZA_FURRO.get())) {
            victim.addEffect(EffectUtil.of("glowing", 200, 0));
        } else if (weapon.is(ModItems.KATANA_ROSA.get()) || weapon.is(ModItems.DAGA_FEMBOY.get())) {
            server.sendParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                    12, 0.3D, 0.5D, 0.3D, 0.1D);
        } else if (weapon.is(ModItems.ESPADA_ROSA.get())) {
            server.sendParticles(ParticleTypes.HEART, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                    6, 0.3D, 0.4D, 0.3D, 0.0D);
        } else if (weapon.is(ModItems.MARTILLO_FEMBOY.get())) {
            victim.addEffect(EffectUtil.of("slowness", 80, 4));
            victim.addEffect(EffectUtil.of("weakness", 80, 1));
            server.sendParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                    20, 0.4D, 0.5D, 0.4D, 0.2D);
        } else if (weapon.is(ModItems.HACHA_FEMBOY.get()) && !sweeping) {
            sweeping = true;
            try {
                for (LivingEntity other : server.getEntitiesOfClass(LivingEntity.class,
                        victim.getBoundingBox().inflate(3.0D),
                        e -> e != victim && e != attacker && e instanceof Enemy && e.isAlive())) {
                    other.hurtServer(server, event.getSource(), event.getNewDamage() * 0.6F);
                }
                server.sendParticles(ParticleTypes.SWEEP_ATTACK, victim.getX(), victim.getY() + 1.0D,
                        victim.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D);
            } finally {
                sweeping = false;
            }
        }
    }

    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || player.tickCount % 40 != 0) {
            return;
        }
        if (hasFullSet(player)) {
            player.addEffect(EffectUtil.quiet("speed", 120, 1));
            player.addEffect(EffectUtil.quiet("jump_boost", 120, 2));
            player.addEffect(EffectUtil.quiet("regeneration", 120, 1));
            player.addEffect(EffectUtil.quiet("resistance", 120, 1));
        }
        if (hasReinaSet(player)) {
            player.addEffect(EffectUtil.quiet("strength", 120, 1));
            player.addEffect(EffectUtil.quiet("speed", 120, 2));
            player.addEffect(EffectUtil.quiet("regeneration", 120, 2));
            player.addEffect(EffectUtil.quiet("resistance", 120, 2));
            player.addEffect(EffectUtil.quiet("night_vision", 260, 0));
        }
    }

    private static boolean hasReinaSet(Player player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.REINA_HELMET.get())
                && player.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.REINA_CHESTPLATE.get())
                && player.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.REINA_LEGGINGS.get())
                && player.getItemBySlot(EquipmentSlot.FEET).is(ModItems.REINA_BOOTS.get());
    }

    private static boolean hasFullSet(Player player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.FEMBOY_HELMET.get())
                && player.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.FEMBOY_CHESTPLATE.get())
                && player.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.FEMBOY_LEGGINGS.get())
                && player.getItemBySlot(EquipmentSlot.FEET).is(ModItems.FEMBOY_BOOTS.get());
    }
}
