package dev.femboymod.event;

import dev.femboymod.registry.ModEffects;
import dev.femboymod.registry.ModItems;
import dev.femboymod.util.EffectUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;

/** Efectos de la comida especial. */
public class ItemEvents {
    public static void onFinish(LivingEntityUseItemEvent.Finish event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ItemStack stack = event.getItem();
        if (stack.is(ModItems.MANZANA_FEMBOY.get())) {
            player.addEffect(EffectUtil.of("regeneration", 200, 2));
            player.addEffect(EffectUtil.of("absorption", 2400, 3));
            player.addEffect(EffectUtil.of("resistance", 600, 1));
        } else if (stack.is(ModItems.FRUTA_ROSA.get())) {
            player.addEffect(EffectUtil.of("speed", 300, 1));
            player.addEffect(EffectUtil.of("regeneration", 100, 0));
            player.removeEffect(ModEffects.PLAGA_ROSA);
        }
    }
}
