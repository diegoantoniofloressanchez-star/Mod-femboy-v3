package dev.femboymod.event;

import dev.femboymod.FemboyMod;
import dev.femboymod.registry.ModBlocks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Teletransporte del portal de Femboy. Usa comandos (/execute in ... run tp) para no depender
 * de la API interna de cambio de dimension. Guarda de donde vienes en una etiqueta del jugador.
 */
public class PortalEvents {
    private static final String BACK_PREFIX = "femboy_back_";
    private static final ResourceKey<Level> REINO = ResourceKey.create(Registries.DIMENSION,
            ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "reino_femboy"));
    private static final Map<UUID, Long> COOLDOWN = new HashMap<>();

    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        if (player.tickCount % 5 != 0) {
            return;
        }
        BlockPos feet = player.blockPosition();
        BlockPos eyes = BlockPos.containing(player.getEyePosition());
        if (!isPortal(level.getBlockState(feet)) && !isPortal(level.getBlockState(eyes))) {
            return;
        }

        long now = level.getGameTime();
        Long until = COOLDOWN.get(player.getUUID());
        if (until != null && now < until) {
            return;
        }
        COOLDOWN.put(player.getUUID(), now + 200L);

        MinecraftServer server = level.getServer();
        if (level.dimension().equals(REINO)) {
            volverAlMundo(server, player);
        } else {
            irAlReino(server, player);
        }
    }

    private static boolean isPortal(BlockState state) {
        return state.is(ModBlocks.PORTAL_FEMBOY.get());
    }

    private static void irAlReino(MinecraftServer server, ServerPlayer player) {
        ServerLevel reino = server.getLevel(REINO);
        if (reino == null) {
            return;
        }
        for (String tag : new ArrayList<>(player.getTags())) {
            if (tag.startsWith(BACK_PREFIX)) {
                player.removeTag(tag);
            }
        }
        player.addTag(BACK_PREFIX + String.format(Locale.ROOT, "%.2f_%.2f_%.2f",
                player.getX(), player.getY(), player.getZ()));

        BlockPos spot = findLand(reino);
        construirPortalDeRegreso(reino, spot);
        runCommand(server, String.format(Locale.ROOT,
                "execute in femboy:reino_femboy run tp %s %.1f %d %.1f 180 0",
                player.getStringUUID(), spot.getX() + 1.0D, spot.getY(), spot.getZ() + 3.5D));
    }

    private static void volverAlMundo(MinecraftServer server, ServerPlayer player) {
        String back = null;
        for (String tag : player.getTags()) {
            if (tag.startsWith(BACK_PREFIX)) {
                back = tag.substring(BACK_PREFIX.length());
                break;
            }
        }
        if (back != null) {
            String[] p = back.split("_");
            runCommand(server, "execute in minecraft:overworld run tp " + player.getStringUUID()
                    + " " + p[0] + " " + p[1] + " " + p[2]);
        } else {
            runCommand(server, "execute in minecraft:overworld positioned 0 0 0 positioned over world_surface run tp "
                    + player.getStringUUID() + " ~ ~ ~");
        }
    }

    private static void runCommand(MinecraftServer server, String command) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
    }

    /** Busca (siempre el mismo) terreno firme cerca del origen, evitando oceanos. */
    private static BlockPos findLand(ServerLevel level) {
        ChunkGenerator generator = level.getChunkSource().getGenerator();
        RandomState randomState = level.getChunkSource().randomState();
        for (int radius = 0; radius <= 600; radius += 24) {
            int steps = radius == 0 ? 1 : 12;
            for (int i = 0; i < steps; i++) {
                double angle = i * (Math.PI * 2.0D / steps);
                int x = (int) Math.round(Math.cos(angle) * radius);
                int z = (int) Math.round(Math.sin(angle) * radius);
                int y = generator.getBaseHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG, level, randomState);
                if (y > 68 && y < 150) {
                    return new BlockPos(x, y, z);
                }
            }
        }
        return new BlockPos(0, 100, 0);
    }

    /** Plataforma + portal de regreso (marco de 4x5 a lo largo del eje X) sobre el terreno elegido. */
    private static void construirPortalDeRegreso(ServerLevel reino, BlockPos spot) {
        int ox = spot.getX();
        int oy = spot.getY();
        int oz = spot.getZ();
        for (int dx = -5; dx <= 6; dx++) {
            for (int dz = -4; dz <= 6; dz++) {
                reino.setBlock(new BlockPos(ox + dx, oy - 1, oz + dz), Blocks.STONE_BRICKS.defaultBlockState(), 3);
                for (int dy = 0; dy <= 6; dy++) {
                    reino.setBlock(new BlockPos(ox + dx, oy + dy, oz + dz), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
        for (int dx = -1; dx <= 2; dx++) {
            for (int dy = 0; dy <= 4; dy++) {
                boolean border = dx == -1 || dx == 2 || dy == 0 || dy == 4;
                reino.setBlock(new BlockPos(ox + dx, oy + dy, oz),
                        (border ? ModBlocks.MARCO_PORTAL : ModBlocks.PORTAL_FEMBOY).get().defaultBlockState(), 3);
            }
        }
        reino.setBlock(new BlockPos(ox - 2, oy, oz), Blocks.SEA_LANTERN.defaultBlockState(), 3);
        reino.setBlock(new BlockPos(ox + 3, oy, oz), Blocks.SEA_LANTERN.defaultBlockState(), 3);
    }
}
