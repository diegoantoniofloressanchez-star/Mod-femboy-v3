package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import dev.femboymod.item.BaculoCorazonesItem;
import dev.femboymod.item.BrujulaFemboyItem;
import dev.femboymod.item.CanonBilletesItem;
import dev.femboymod.item.LibroFemboyItem;
import dev.femboymod.item.PlumaReinaItem;
import dev.femboymod.item.OrbeFemboyItem;
import dev.femboymod.item.VacunaItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.equipment.ArmorType;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(FemboyMod.MOD_ID);

    // --- Fase 1 ---
    public static final DeferredItem<Item> BILLETE = ITEMS.registerSimpleItem("billete", new Item.Properties());

    public static final DeferredItem<Item> BILLETE_FEMBOY = ITEMS.registerSimpleItem(
            "billete_femboy", new Item.Properties().rarity(Rarity.EPIC));

    public static final DeferredItem<BlockItem> FEMBOYFICADORA = ITEMS.registerSimpleBlockItem(ModBlocks.FEMBOYFICADORA);

    // --- Fase 2: armas ---
    public static final DeferredItem<Item> ESPADA_ROSA = ITEMS.registerItem("espada_rosa",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL, 5.0F, -2.4F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> HACHA_FEMBOY = ITEMS.registerItem("hacha_femboy",
            props -> new AxeItem(ModMaterials.FEMBOY_TOOL, 8.0F, -3.0F, props.rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> MARTILLO_FEMBOY = ITEMS.registerItem("martillo_femboy",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL, 7.0F, -3.1F).rarity(Rarity.EPIC)));

    // --- Fase 2: armas OP ---
    public static final DeferredItem<Item> ORBE_FEMBOY = ITEMS.registerItem("orbe_femboy",
            props -> new OrbeFemboyItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> BACULO_CORAZONES = ITEMS.registerItem("baculo_corazones",
            props -> new BaculoCorazonesItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> CANON_BILLETES = ITEMS.registerItem("canon_billetes",
            props -> new CanonBilletesItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    // --- Fase 2: armadura ---
    public static final DeferredItem<Item> FEMBOY_HELMET = ITEMS.registerItem("femboy_helmet",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.HELMET).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FEMBOY_CHESTPLATE = ITEMS.registerItem("femboy_chestplate",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.CHESTPLATE).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FEMBOY_LEGGINGS = ITEMS.registerItem("femboy_leggings",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.LEGGINGS).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FEMBOY_BOOTS = ITEMS.registerItem("femboy_boots",
            props -> new Item(props.humanoidArmor(ModMaterials.FEMBOY_ARMOR, ArmorType.BOOTS).rarity(Rarity.EPIC)));

    // --- Fase 3: plaga y laboratorio ---
    public static final DeferredItem<Item> MUESTRA_PLAGA = ITEMS.registerSimpleItem("muestra_plaga", new Item.Properties());

    public static final DeferredItem<Item> VACUNA = ITEMS.registerItem("vacuna",
            props -> new VacunaItem(props.stacksTo(16).rarity(Rarity.RARE)));

    public static final DeferredItem<Item> ESPADA_ANTIPLAGA = ITEMS.registerItem("espada_antiplaga",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL, 4.0F, -2.4F).rarity(Rarity.EPIC)));

    public static final DeferredItem<BlockItem> MESA_INVESTIGACION = ITEMS.registerSimpleBlockItem(ModBlocks.MESA_INVESTIGACION);

    // --- Fase 4: portal, dimension y jefa ---
    public static final DeferredItem<Item> LLAVE_FEMBOY = ITEMS.registerSimpleItem(
            "llave_femboy", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    public static final DeferredItem<Item> CORAZON_REINA = ITEMS.registerSimpleItem(
            "corazon_reina", new Item.Properties().rarity(Rarity.EPIC));

    public static final DeferredItem<Item> TROFEO_REINA = ITEMS.registerSimpleItem(
            "trofeo_reina", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    public static final DeferredItem<BlockItem> MARCO_PORTAL = ITEMS.registerSimpleBlockItem(ModBlocks.MARCO_PORTAL);

    // --- Brujula y misiones ---
    public static final DeferredItem<Item> BRUJULA = ITEMS.registerItem("brujula_femboy",
            props -> new BrujulaFemboyItem(props.stacksTo(1).rarity(Rarity.RARE)));

    // --- Fase 5: mas objetos especiales ---
    public static final DeferredItem<Item> GEMA_ROSA = ITEMS.registerSimpleItem("gema_rosa", new Item.Properties().rarity(Rarity.RARE));

    public static final DeferredItem<Item> DAGA_FEMBOY = ITEMS.registerItem("daga_femboy",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL_PRO, 2.0F, -1.2F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> KATANA_ROSA = ITEMS.registerItem("katana_rosa",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL_PRO, 6.0F, -2.0F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> GUADANA_REINA = ITEMS.registerItem("guadana_reina",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL_PRO, 8.0F, -3.0F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> LANZA_FURRO = ITEMS.registerItem("lanza_furro",
            props -> new Item(props.sword(ModMaterials.FEMBOY_TOOL_PRO, 4.0F, -2.2F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> PICO_FEMBOY = ITEMS.registerItem("pico_femboy",
            props -> new Item(props.pickaxe(ModMaterials.FEMBOY_TOOL_PRO, 1.0F, -2.8F).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> PALA_FEMBOY = ITEMS.registerItem("pala_femboy",
            props -> new ShovelItem(ModMaterials.FEMBOY_TOOL_PRO, 1.5F, -3.0F, props.rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> AZADA_FEMBOY = ITEMS.registerItem("azada_femboy",
            props -> new HoeItem(ModMaterials.FEMBOY_TOOL_PRO, -3.0F, 0.0F, props.rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> REINA_HELMET = ITEMS.registerItem("reina_helmet",
            props -> new Item(props.humanoidArmor(ModMaterials.REINA_ARMOR, ArmorType.HELMET).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> REINA_CHESTPLATE = ITEMS.registerItem("reina_chestplate",
            props -> new Item(props.humanoidArmor(ModMaterials.REINA_ARMOR, ArmorType.CHESTPLATE).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> REINA_LEGGINGS = ITEMS.registerItem("reina_leggings",
            props -> new Item(props.humanoidArmor(ModMaterials.REINA_ARMOR, ArmorType.LEGGINGS).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> REINA_BOOTS = ITEMS.registerItem("reina_boots",
            props -> new Item(props.humanoidArmor(ModMaterials.REINA_ARMOR, ArmorType.BOOTS).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> MANZANA_FEMBOY = ITEMS.registerItem("manzana_femboy",
            props -> new Item(props.food(new FoodProperties.Builder()
                    .nutrition(8).saturationModifier(1.2F).alwaysEdible().build()).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> FRUTA_ROSA = ITEMS.registerItem("fruta_rosa",
            props -> new Item(props.food(new FoodProperties.Builder()
                    .nutrition(5).saturationModifier(0.8F).alwaysEdible().build()).rarity(Rarity.RARE)));

    public static final DeferredItem<Item> PLUMA_REINA = ITEMS.registerItem("pluma_reina",
            props -> new PlumaReinaItem(props.stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<Item> LIBRO_FEMBOY = ITEMS.registerItem("libro_femboy",
            props -> new LibroFemboyItem(props.stacksTo(1).rarity(Rarity.RARE)));

    // --- Decoracion de laboratorio (items de bloque) ---
    public static final DeferredItem<BlockItem> COMPUTADORA_LAB = ITEMS.registerSimpleBlockItem(ModBlocks.COMPUTADORA_LAB);
    public static final DeferredItem<BlockItem> TANQUE_PLAGA = ITEMS.registerSimpleBlockItem(ModBlocks.TANQUE_PLAGA);
    public static final DeferredItem<BlockItem> PANEL_CONTROL = ITEMS.registerSimpleBlockItem(ModBlocks.PANEL_CONTROL);
    public static final DeferredItem<BlockItem> LAMPARA_LAB = ITEMS.registerSimpleBlockItem(ModBlocks.LAMPARA_LAB);
}
