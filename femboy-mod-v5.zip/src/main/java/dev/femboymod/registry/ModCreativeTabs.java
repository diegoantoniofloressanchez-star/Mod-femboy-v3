package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FemboyMod.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FEMBOY_TAB = TABS.register(
            "femboy",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.femboy"))
                    .icon(() -> new ItemStack(ModItems.BILLETE_FEMBOY.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.BILLETE.get());
                        output.accept(ModItems.BILLETE_FEMBOY.get());
                        output.accept(ModItems.FEMBOYFICADORA.get());
                        output.accept(ModItems.ESPADA_ROSA.get());
                        output.accept(ModItems.HACHA_FEMBOY.get());
                        output.accept(ModItems.MARTILLO_FEMBOY.get());
                        output.accept(ModItems.ORBE_FEMBOY.get());
                        output.accept(ModItems.BACULO_CORAZONES.get());
                        output.accept(ModItems.CANON_BILLETES.get());
                        output.accept(ModItems.FEMBOY_HELMET.get());
                        output.accept(ModItems.FEMBOY_CHESTPLATE.get());
                        output.accept(ModItems.FEMBOY_LEGGINGS.get());
                        output.accept(ModItems.FEMBOY_BOOTS.get());
                        output.accept(ModItems.MUESTRA_PLAGA.get());
                        output.accept(ModItems.VACUNA.get());
                        output.accept(ModItems.ESPADA_ANTIPLAGA.get());
                        output.accept(ModItems.MESA_INVESTIGACION.get());
                        output.accept(ModItems.LLAVE_FEMBOY.get());
                        output.accept(ModItems.CORAZON_REINA.get());
                        output.accept(ModItems.TROFEO_REINA.get());
                        output.accept(ModItems.MARCO_PORTAL.get());
                        output.accept(ModItems.BRUJULA.get());
                        output.accept(ModItems.LIBRO_FEMBOY.get());
                        output.accept(ModItems.GEMA_ROSA.get());
                        output.accept(ModItems.DAGA_FEMBOY.get());
                        output.accept(ModItems.KATANA_ROSA.get());
                        output.accept(ModItems.GUADANA_REINA.get());
                        output.accept(ModItems.LANZA_FURRO.get());
                        output.accept(ModItems.PICO_FEMBOY.get());
                        output.accept(ModItems.PALA_FEMBOY.get());
                        output.accept(ModItems.AZADA_FEMBOY.get());
                        output.accept(ModItems.REINA_HELMET.get());
                        output.accept(ModItems.REINA_CHESTPLATE.get());
                        output.accept(ModItems.REINA_LEGGINGS.get());
                        output.accept(ModItems.REINA_BOOTS.get());
                        output.accept(ModItems.MANZANA_FEMBOY.get());
                        output.accept(ModItems.FRUTA_ROSA.get());
                        output.accept(ModItems.PLUMA_REINA.get());
                        output.accept(ModItems.COMPUTADORA_LAB.get());
                        output.accept(ModItems.TANQUE_PLAGA.get());
                        output.accept(ModItems.PANEL_CONTROL.get());
                        output.accept(ModItems.LAMPARA_LAB.get());
                    })
                    .build());
}
