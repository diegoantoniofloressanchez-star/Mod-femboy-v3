package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import java.util.EnumMap;
import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public class ModMaterials {
    public static final TagKey<Item> REPAIRS_TOOLS = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "repairs_tools"));
    public static final TagKey<Item> REPAIRS_ARMOR = TagKey.create(Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "repairs_armor"));

    /** Herramientas/armas: nivel parecido al diamante, sin netherite. */
    public static final ToolMaterial FEMBOY_TOOL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_IRON_TOOL, 1800, 8.0F, 3.0F, 22, REPAIRS_TOOLS);

    public static final ResourceKey<EquipmentAsset> FEMBOY_ASSET = ResourceKey.create(
            EquipmentAssets.ROOT_ID, ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "femboy"));

    /** Armadura: defensa de diamante, el poder real esta en el bonus del set completo. */
    public static final ArmorMaterial FEMBOY_ARMOR = new ArmorMaterial(
            33,
            Util.make(new EnumMap<>(ArmorType.class), map -> {
                map.put(ArmorType.BOOTS, 3);
                map.put(ArmorType.LEGGINGS, 6);
                map.put(ArmorType.CHESTPLATE, 8);
                map.put(ArmorType.HELMET, 3);
                map.put(ArmorType.BODY, 11);
            }),
            25,
            SoundEvents.ARMOR_EQUIP_IRON,
            2.0F,
            0.0F,
            REPAIRS_ARMOR,
            FEMBOY_ASSET);

    /** Herramientas pro: pueden minar todo (nivel netherite) y duran mucho. */
    public static final ToolMaterial FEMBOY_TOOL_PRO = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2600, 9.0F, 4.0F, 25, REPAIRS_TOOLS);

    public static final ResourceKey<EquipmentAsset> REINA_ASSET = ResourceKey.create(
            EquipmentAssets.ROOT_ID, ResourceLocation.fromNamespaceAndPath(FemboyMod.MOD_ID, "reina"));

    /** Armadura de la Reina: mejor que la del Femboy. */
    public static final ArmorMaterial REINA_ARMOR = new ArmorMaterial(
            40,
            Util.make(new EnumMap<>(ArmorType.class), map -> {
                map.put(ArmorType.BOOTS, 4);
                map.put(ArmorType.LEGGINGS, 7);
                map.put(ArmorType.CHESTPLATE, 9);
                map.put(ArmorType.HELMET, 4);
                map.put(ArmorType.BODY, 14);
            }),
            30,
            SoundEvents.ARMOR_EQUIP_DIAMOND,
            3.5F,
            0.1F,
            REPAIRS_ARMOR,
            REINA_ASSET);
}
