package dev.femboymod.registry;

import dev.femboymod.FemboyMod;
import dev.femboymod.block.FemboyficadoraBlock;
import dev.femboymod.block.MarcoPortalBlock;
import dev.femboymod.block.MesaInvestigacionBlock;
import dev.femboymod.block.PortalFemboyBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(FemboyMod.MOD_ID);

    public static final DeferredBlock<Block> FEMBOYFICADORA = BLOCKS.registerBlock(
            "femboyficadora",
            FemboyficadoraBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(3.5F)
                    .sound(SoundType.METAL));

    public static final DeferredBlock<Block> MESA_INVESTIGACION = BLOCKS.registerBlock(
            "mesa_investigacion",
            MesaInvestigacionBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SNOW)
                    .strength(3.0F)
                    .sound(SoundType.METAL));

    public static final DeferredBlock<Block> MARCO_PORTAL = BLOCKS.registerBlock(
            "marco_portal",
            MarcoPortalBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(state -> 7)
                    .sound(SoundType.AMETHYST));

    public static final DeferredBlock<Block> PORTAL_FEMBOY = BLOCKS.registerBlock(
            "portal_femboy",
            PortalFemboyBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_MAGENTA)
                    .noCollission()
                    .noLootTable()
                    .strength(-1.0F, 3600000.0F)
                    .lightLevel(state -> 11)
                    .sound(SoundType.GLASS));

    // --- Decoracion de laboratorio ---
    public static final DeferredBlock<Block> COMPUTADORA_LAB = BLOCKS.registerBlock("computadora_lab", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(2.0F).sound(SoundType.METAL).lightLevel(state -> 6));

    public static final DeferredBlock<Block> TANQUE_PLAGA = BLOCKS.registerBlock("tanque_plaga", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(1.5F).sound(SoundType.GLASS).lightLevel(state -> 10));

    public static final DeferredBlock<Block> PANEL_CONTROL = BLOCKS.registerBlock("panel_control", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(2.0F).sound(SoundType.METAL).lightLevel(state -> 4));

    public static final DeferredBlock<Block> LAMPARA_LAB = BLOCKS.registerBlock("lampara_lab", Block::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(1.0F).sound(SoundType.GLASS).lightLevel(state -> 15));
}
