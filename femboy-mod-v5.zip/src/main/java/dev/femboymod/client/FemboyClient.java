package dev.femboymod.client;

import dev.femboymod.FemboyMod;
import dev.femboymod.entity.FurroEntity;
import dev.femboymod.entity.ReinaFurraEntity;
import dev.femboymod.registry.ModEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod(value = FemboyMod.MOD_ID, dist = Dist.CLIENT)
public class FemboyClient {
    public FemboyClient(IEventBus modBus, ModContainer container) {
        modBus.addListener(FemboyClient::registerRenderers);
        NeoForge.EVENT_BUS.addListener(QuestHud::onRender);
        NeoForge.EVENT_BUS.addListener(IdiomaButton::onScreenInit);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FEMBOY.get(), FemboyRenderer::new);
        event.registerEntityRenderer(ModEntities.FURRO_GUERRERO.get(),
                ctx -> new FurroRenderer<FurroEntity>(ctx, "furro_guerrero"));
        event.registerEntityRenderer(ModEntities.FURRO_ARQUERO.get(),
                ctx -> new FurroRenderer<FurroEntity>(ctx, "furro_arquero"));
        event.registerEntityRenderer(ModEntities.FURRO_TANQUE.get(),
                ctx -> new FurroRenderer<FurroEntity>(ctx, "furro_tanque"));
        event.registerEntityRenderer(ModEntities.REINA_FURRA.get(),
                ctx -> new FurroRenderer<ReinaFurraEntity>(ctx, "reina_furra"));
    }
}
