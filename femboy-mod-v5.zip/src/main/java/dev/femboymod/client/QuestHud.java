package dev.femboymod.client;

import dev.femboymod.quest.ClientQuestState;
import dev.femboymod.registry.ModItems;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

/** Panel de mision en la esquina superior izquierda + flecha de la brujula (al sostenerla). */
public class QuestHud {
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
    private static final int MAX_STAGE = 19;

    public static void onRender(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || ClientQuestState.stage < 0) {
            return;
        }
        GuiGraphics g = event.getGuiGraphics();
        Font font = mc.font;
        int stage = ClientQuestState.stage;

        Component title = stage >= MAX_STAGE
                ? Component.translatable("quest.femboy.titulo_completo")
                : Component.translatable("quest.femboy.titulo", stage + 1, MAX_STAGE);
        List<FormattedCharSequence> lines = font.split(Component.translatable("quest.femboy." + stage), 150);

        String guide = guideLine(mc);

        int width = 158;
        int height = 8 + 11 + lines.size() * 10 + (guide != null ? 12 : 0);
        int x = 6;
        int y = 6;
        g.fill(x, y, x + width, y + height, 0x99000000);
        g.fill(x, y, x + 2, y + height, 0xFFFF69B4);
        g.drawString(font, title, x + 6, y + 4, 0xFFFF9AD5);
        int ty = y + 16;
        for (FormattedCharSequence line : lines) {
            g.drawString(font, line, x + 6, ty, 0xFFFFFFFF);
            ty += 10;
        }
        if (guide != null) {
            g.drawString(font, guide, x + 6, ty + 2, 0xFFFFE066);
        }
    }

    /** Flecha + distancia, solo si llevas la brujula en la mano y hay objetivo en esta dimension. */
    private static String guideLine(Minecraft mc) {
        boolean holding = mc.player.getMainHandItem().is(ModItems.BRUJULA.get())
                || mc.player.getOffhandItem().is(ModItems.BRUJULA.get());
        if (!holding || !ClientQuestState.hasTarget || mc.level == null) {
            return null;
        }
        boolean inReino = mc.level.dimension().location().getPath().equals("reino_femboy");
        if (inReino != ClientQuestState.targetReino) {
            return null;
        }
        double dx = ClientQuestState.targetX + 0.5D - mc.player.getX();
        double dz = ClientQuestState.targetZ + 0.5D - mc.player.getZ();
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float relative = Mth.wrapDegrees(targetYaw - mc.player.getYRot());
        if (relative < 0) {
            relative += 360.0F;
        }
        int idx = Math.round(relative / 45.0F) % 8;
        int meters = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
        return ARROWS[idx] + "  " + meters + " m";
    }
}
