package dev.femboymod.client;

import net.minecraft.client.Minecraft;

/** Abre el libro (solo cliente). Se mantiene aparte para que el servidor no cargue clases de cliente. */
public final class ClientBook {
    private ClientBook() {}

    public static void open() {
        Minecraft.getInstance().setScreen(new LibroScreen());
    }
}
