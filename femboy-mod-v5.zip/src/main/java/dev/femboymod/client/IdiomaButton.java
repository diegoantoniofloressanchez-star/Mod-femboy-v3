package dev.femboymod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Anade el boton "Language / Idioma" en la esquina superior izquierda del menu principal. */
public class IdiomaButton {
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (event.getScreen() instanceof TitleScreen screen) {
            event.addListener(Button.builder(Component.literal("Language / Idioma"),
                            b -> Minecraft.getInstance().setScreen(new IdiomaScreen(screen)))
                    .bounds(6, 6, 120, 20).build());
        }
    }
}
