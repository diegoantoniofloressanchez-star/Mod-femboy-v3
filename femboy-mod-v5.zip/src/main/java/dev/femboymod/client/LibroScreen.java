package dev.femboymod.client;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

/** Libro del Femboy: una pagina por crafteo especial, con descripcion y la receta dibujada. */
public class LibroScreen extends Screen {
    private static final int W = 240;
    private static final int H = 190;

    private final List<LibroPaginas.Pagina> pages = LibroPaginas.build();
    private int page = 0;
    private Button prev;
    private Button next;

    public LibroScreen() {
        super(Component.translatable("item.femboy.libro_femboy"));
    }

    @Override
    protected void init() {
        int left = (this.width - W) / 2;
        int top = (this.height - H) / 2;
        this.prev = this.addRenderableWidget(Button.builder(Component.literal("<"), b -> turn(-1))
                .bounds(left + 6, top + H - 26, 36, 20).build());
        this.next = this.addRenderableWidget(Button.builder(Component.literal(">"), b -> turn(1))
                .bounds(left + W - 42, top + H - 26, 36, 20).build());
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose())
                .bounds(left + W / 2 - 40, top + H - 26, 80, 20).build());
        updateButtons();
    }

    private void turn(int delta) {
        this.page = Math.max(0, Math.min(this.pages.size() - 1, this.page + delta));
        updateButtons();
    }

    private void updateButtons() {
        this.prev.active = this.page > 0;
        this.next.active = this.page < this.pages.size() - 1;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int left = (this.width - W) / 2;
        int top = (this.height - H) / 2;
        LibroPaginas.Pagina p = this.pages.get(this.page);

        g.fill(left, top, left + W, top + H, 0xEE1B0F1F);
        g.fill(left, top, left + W, top + 2, 0xFFFF69B4);
        g.fill(left, top + H - 2, left + W, top + H, 0xFFFF69B4);
        g.fill(left, top, left + 2, top + H, 0xFFFF69B4);
        g.fill(left + W - 2, top, left + W, top + H, 0xFFFF69B4);

        g.drawCenteredString(this.font, Component.translatable("libro.femboy." + p.id() + ".titulo"),
                left + W / 2, top + 10, 0xFFFF9AD5);

        List<FormattedCharSequence> lines = this.font.split(
                Component.translatable("libro.femboy." + p.id() + ".desc"), W - 24);
        int y = top + 28;
        for (FormattedCharSequence line : lines) {
            g.drawString(this.font, line, left + 12, y, 0xFFFFFFFF);
            y += 10;
        }

        if (p.result() != null) {
            int gx = left + W / 2 - 62;
            int gy = top + 104;
            ItemStack[] grid = p.grid();
            for (int i = 0; i < 9; i++) {
                int sx = gx + (i % 3) * 18;
                int sy = gy + (i / 3) * 18;
                slot(g, sx, sy);
                if (grid != null && !grid[i].isEmpty()) {
                    g.renderItem(grid[i], sx + 1, sy + 1);
                }
            }
            g.drawString(this.font, "\u2192", gx + 60, gy + 22, 0xFFFFE066);
            slot(g, gx + 76, gy + 18);
            g.renderItem(p.result(), gx + 77, gy + 19);
        }

        g.drawCenteredString(this.font, (this.page + 1) + " / " + this.pages.size(),
                left + W / 2, top + H - 40, 0xFF9A8AA0);
    }

    private void slot(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF55485A);
        g.fill(x + 1, y + 1, x + 17, y + 17, 0xFF8B8190);
    }
}
