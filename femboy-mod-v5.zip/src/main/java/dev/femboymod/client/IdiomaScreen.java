package dev.femboymod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/** Menu para elegir el idioma del juego (y del mod): English o Espanol (Mexico). */
public class IdiomaScreen extends Screen {
    private final Screen parent;

    public IdiomaScreen(Screen parent) {
        super(Component.literal("Language / Idioma"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 30;
        this.addRenderableWidget(Button.builder(Component.literal("English"), b -> setLanguage("en_us"))
                .bounds(cx - 100, y, 200, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Espa\u00f1ol (M\u00e9xico)"), b -> setLanguage("es_mx"))
                .bounds(cx - 100, y + 26, 200, 20).build());
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_BACK, b -> this.onClose())
                .bounds(cx - 100, y + 62, 200, 20).build());
    }

    private void setLanguage(String code) {
        Minecraft mc = Minecraft.getInstance();
        mc.getLanguageManager().setSelected(code);
        mc.options.languageCode = code;
        mc.options.save();
        mc.reloadResourcePacks();
        mc.setScreen(this.parent);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(this.parent);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 60, 0xFFFFFFFF);
    }
}
