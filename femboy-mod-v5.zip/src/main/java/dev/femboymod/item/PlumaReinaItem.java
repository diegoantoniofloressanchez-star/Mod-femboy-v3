package dev.femboymod.item;

import dev.femboymod.util.EffectUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Pluma de la Reina: impulso hacia adelante y caida lenta. */
public class PlumaReinaItem extends Item {
    public PlumaReinaItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level instanceof ServerLevel server) {
            Vec3 look = player.getLookAngle();
            player.setDeltaMovement(look.x * 1.6D, Math.max(look.y * 1.2D, 0.35D), look.z * 1.6D);
            player.hurtMarked = true;
            player.addEffect(EffectUtil.of("slow_falling", 140, 0));
            server.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 0.5D, player.getZ(),
                    10, 0.4D, 0.2D, 0.4D, 0.0D);
            level.playSound(null, player.blockPosition(), SoundEvents.PHANTOM_FLAP, SoundSource.PLAYERS, 1.0F, 1.4F);
        }
        player.getCooldowns().addCooldown(player.getItemInHand(hand), 60);
        return InteractionResult.SUCCESS;
    }
}
