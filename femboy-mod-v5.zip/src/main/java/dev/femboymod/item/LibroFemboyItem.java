package dev.femboymod.item;

import dev.femboymod.client.ClientBook;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Libro del Femboy: guia con las resenas y recetas de cada crafteo especial. */
public class LibroFemboyItem extends Item {
    public LibroFemboyItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            ClientBook.open();
        }
        return InteractionResult.SUCCESS;
    }
}
